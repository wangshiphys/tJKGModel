import matplotlib.pyplot as plt
import numpy as np


data = np.loadtxt("stripez.dat")

kpoints = np.reshape(data[:, 0], (-1, 499))
omegas = np.reshape(data[:, 1], (-1, 499))
spectrum = np.reshape(data[:, 2], (-1, 499))

fig, ax = plt.subplots()
cs =ax.pcolormesh(
    kpoints, omegas, spectrum,
    cmap="hot_r", shading="gouraud",
    vmin=0.0, vmax=1
)
fig.colorbar(cs, ax=ax)
plt.show()
plt.close("all")
