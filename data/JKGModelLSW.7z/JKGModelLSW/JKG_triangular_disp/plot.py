import matplotlib.pyplot as plt
import numpy as np

fig, ax = plt.subplots()
for index in [1, 2]:
    data = np.loadtxt("stipeB_{0}.dat".format(index))
    ax.plot(data[:, 0], data[:, 1])
plt.show()
plt.close("all")
